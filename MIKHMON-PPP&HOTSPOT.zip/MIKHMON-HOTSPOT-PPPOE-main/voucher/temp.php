<?php $genu="raFfbmVmZWJkZmJpZmNiZa2waXmTqpqwaZWwa2FiaFJlaGFitmGwaK92oaSTmp2X";?>
