<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>aWNlbA==');


$data['My-Mikrotik'] = array ('1'=>'My-Mikrotik!103.81.199.18:2024','My-Mikrotik@|@API','My-Mikrotik#|#i3mE','My-Mikrotik%SHR','My-Mikrotik^shr.hotspots.local','My-Mikrotik&BDT','My-Mikrotik*10','My-Mikrotik(1','My-Mikrotik)','My-Mikrotik=10','My-Mikrotik@!@enable');
